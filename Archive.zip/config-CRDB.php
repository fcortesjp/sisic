<?php
$database = "franc451_CR2013";  // the name of the database.
$server = "localhost";  // server to connect to.
$db_user = "franc451_frank34";  // mysql username to access the database with.
$db_pass = "52190Lkwdic";  // mysql password to access the database with.
$link = mysql_connect($server, $db_user, $db_pass);
mysql_select_db($database,$link);
?>