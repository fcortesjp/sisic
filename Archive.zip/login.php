<html>
	<head>
		<title>Instituto Copesal - Ingreso</title>
	</head>
	<body>
		<div id="containt" align="center">
			<form action="loginprocess.php" method="post">
				<div id="header" align="center"><h1 class="sansserif">INSTITUTO COPESAL</h1></div>
				</br>
				</br>
				<table>
					<tr>
						<td>Nombre de Usuario:</td>
						<td><input type="text" name="userName"></td>
					</tr>
					</br>
					</br>
					<tr>
						<td>Clave:</td>
						<td><input type="password" name="userPass"></td>
					</tr>
				</table>
				</br>
				<input type="submit" value="Ingresar" align="center">
			</form>
		</div>
	</body>
</html>