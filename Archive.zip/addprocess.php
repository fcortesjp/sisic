<script>
function gobackSameSubject()
{
	var addprocessForm = document.getElementById ("addprocess");
	addprocessForm.action = "IngresarLeI.php"	
	addprocessForm.submit();
	 	
}

function gobackNewSubject()
{
	var addprocessForm = document.getElementById ("addprocess");
	addprocessForm.action = "admin.php"	
	addprocessForm.submit();
	 	
}
</script>
<?php
	session_start();  //session
    if(isset($_SESSION['currentUser']))
	{
		
		$currentUser = $_SESSION['currentUser'];
	
	    include("functions.php");
		
		$cid = $_POST['classid']; // the classid from the dropdown from previous page.
		$csubject = $_POST['classsub']; // the classSubject from the dropdown from previous page.
		// variables
		
		$saveProcess;
		
		
		
		echo "Bienvenido(a) ".$currentUser; // indicate that you have logged and do whatever
		echo "</br>";
		echo "<a href='logout.php'>Logout</a>";
		echo "</br>";
		$saveProcess = btnsave_Click();
		echo "<form name='addprocess' id='addprocess' method='post' >";
			echo "<input type='hidden' id = 'classid' name='classid' value='".$cid."'>";
			echo "<input type='hidden' id = 'classsub' name='classsub' value='".$csubject."'>";
			echo '<div id="header" align="center"><h2 class="sansserif">Resultados</h2></div>';
			echo "</br>";
			echo "<table align = 'center'>";
			
				echo "<tr>";
					echo "<td align='center' width='600' colspan='2'>";
					if ($saveProcess == 1) 
					{
						echo 'Logros e Indicadores fueron guardados';
					} else {
						echo "$saveProcess";
					}
					echo "</br>";
					echo "</td>";
				echo "</tr>";
				echo "<tr>";
					echo "<td align='center' width='200'>";
						echo "<button onclick='gobackSameSubject()'>Adicionar logro para la misma materia</button>";
					echo "</td>";
					echo "<td align='center' width='200'>";
						echo "<button onclick='gobackNewSubject()'>Adicionar logro para nueva materia</button>";
					echo "</td>";
				echo "</tr>";
			echo "</table>";	
		echo "</form>";
		}
		else
		{
			// indicate that the user has not logged in yet
	            echo "usted no ha sido autenticado"; //otherwise say your are not logged in.
		}
	 
?>