<?php
    	/*
		 *//**
		 * AddGoal function
		 * will execute the adding of the Goal to the database when called
		 * and will return a TRUE if the insertion completes, or FALSE if it doesnt
		 *  
		 */
    	
    	function AddGoal(&$goalString, &$periodNumber) 
		{
				//variables
				
				$goalID = 0; //default value that only changes if it works
				$msg = "";
				
				if (($goalString <> "" ) && ( $periodNumber <> 0)) //simple data validation
				{
					
					//set the connection parameters for the database
					
					include("config-CRDB.php"); //including config file for data connection
					
					//if the connexion does not work then through an error
					
					if(! $link )
					{
		  				$msg = die('Could not connect: ' . mysql_error());
						echo "<script>alert('$msg')</script>";
						
					}
					else 
					{	
						//set the sql command to enter data with the variables-parameters
						
						$sql = 	"INSERT INTO Goal ".
		       					"(Goal,`Class Grading Period`)" .
		       					"VALUES ('$goalString', '$periodNumber');";
						
						//set the sql command to retrieve the last id of the goal table
						
						$sqlGetLastGoalID = "SELECT Goal.ID ".
											"FROM `Goal` ".
											"ORDER BY Goal.ID DESC ".
											"LIMIT 1;";
							
						
						//proceed with the adding of the information and get confirmation into a variable
						
						$retval = mysql_query( $sql, $link );
						
						//if the confirmation is unsuccesful then display an error, but if all is good display Great success
						
						if(! $retval )
						{
		  					die('Could not enter goal data : ' . mysql_error());
							echo "<script>alert('$msg')</script>";
						}
						else 
						{
							$msg = "Goal data Entered successfully";
							//echo "<script>alert('$msg')</script>";
							
							// now retrieve the last id record
							
							$retlastID = mysql_query( $sqlGetLastGoalID, $link ); //or die("something went wrong: ". mysql_error()); // execute query and put recordset into variable
							
							
							$row = mysql_fetch_array($retlastID); // get the only one row from the recordset
							
							
							// since we got a goal entered and we can get the last goal id, the adding of a goal was a success
							// so returning anything than 0 for the goalID would be configuration that a record was added. 
							
							$goalID = $row['ID']; //get the value field under the the ID column and put it into the goalID variable.
							
							//echo "<script>alert('retlastID = $retlastID, row = $row, goaldID = $goalID ')</script>";
															
						}
						
						// Close de conection
						
						mysql_close($link);
							
					}
					
					
				}
				else //if simple data validation failed then display that info needs to be checked.
				{
					$msg = "Goal Data entered is not correct, Check Data and try again";
					echo "<script>alert('$msg')</script>";
					
				}
				
				//return variable
				
				return $goalID;
					
		}
	
		/**
		 * addIndicator function
		 * will execute the adding of 1 indicator to the database when called
		 * and will return TRUE if the insertion completes, or FALSE if it doesnt
		 *  
		 */	
		
		function addIndicator(&$ind, &$gID, &$cID) 
		{
			//variables
					
			$addIndicatorOK = FALSE; //default value that only changes if it works	
			$msg = "";	
			
			if ($ind <> "" && $gID > 0 && $cID > 0) //simple validation for data entered
			{
					
					//set the connection parameters for the database
					
					include("config-CRDB.php"); //including config file for data connection
					
					//if the connexion does not work then through an error
					
					if(! $link )
					{
		  				$msg = die('Could not connect: ' . mysql_error());
						echo "<script>alert('$msg')</script>";
						
					}
					else 
					{	
						//set the sql command to enter data with the variables-parameters
						/*
						 * rst!Indicator = ind
	        				rst![Class Copesal_ID] = cID
	        				rst!Goal_ID = gID
						 */
						$sql = 	"INSERT INTO Indicator ".
		       					"(Indicator,`Class Copesal_ID`, Goal_ID) ".
		       					"VALUES ('$ind', '$cID', '$gID');";
						
						//proceed with the adding of the information and get confirmation into a variable
						
						$retval = mysql_query( $sql, $link ); // execute the query and save the recordset into a variable
						
						//if the confirmation is unsuccesful then display an error if all good display Great success
						
						if(! $retval )
						{
		  					die('Could not enter indicator data: ' . mysql_error());
							echo "<script>alert('$msg')</script>";
						}
						else 
						{
							$msg = "Entered indicator data successfully";
							//echo "<script>alert('$msg')</script>";
							$addIndicatorOK = TRUE;	//only if the retrieval is true then the return value is True so it works.	
															
						}
						
						// Close de conection
						
						mysql_close($link);
							
					}
					
			} 
			else //if simple data validation failed then display that info needs to be checked.
			{
				$msg = "Indicator Data Entered is not correct, Check Data and try again";
				echo "<script>alert('$msg')</script>";
			}
			
			//variables to be returned
			
			return $addIndicatorOK;
			
			
		}
		
		/**
		 * GoalIndicatorExist function
		 * will execute a query on the database that will check if the indicator 
		 * being added already exist in the database.
		 * and will return TRUE if so, or FALSE if it doesnt
		 * 
		 * note: the goaltext
		 *  
		 */	
		
		function GoalIndicatorExist($prd, $goalText, $firstIndText, $classID) 
		{
			
				//variables
				//echo "<script>alert('GoalIndicatorExist is being executed')</script>";
					
				$giExist = FALSE; //default value that only changes if it the goal/indicator being added exist	
				$msg = "";
					
				//set the connection parameters for the database
				include("config-CRDB.php"); //including config file for data connection
					
				//if the connexion does not work then through an error if it does try to get the data
				
				if(! $link )
				{
		  			$msg = die('Could not connect: ' . mysql_error());
					echo "<script>alert('$msg')</script>";
					
				}
				else 
				{
					//echo "<script>alert('period = $prd, goaltext =  $goalText, firstIndText = $firstIndText, classID = $classID')</script>";
					$sql = 	"SELECT Goal.ID, Goal.`Class Grading Period`, Goal, Indicator, Indicator.`Class Copesal_ID` ".
							"FROM `Indicator` ".
							"INNER JOIN Goal ".
							"ON Goal.ID = Indicator.Goal_ID ".
							"INNER JOIN `Class Copesal` ".
							"ON `Class Copesal`.ID = Indicator.`Class Copesal_ID` ".
							"WHERE `Class Grading Period` = $prd AND  Goal = '$goalText' ".
							"AND Indicator = '$firstIndText' AND `Class Copesal_ID` = '$classID';";
							
					//proceed with the retrieval of info with the query
						
					$retval = mysql_query( $sql, $link ) or die("error in Query");
					
					//change the die(message) to this when debugging a mysql statement during developing so a big message shows 
					//why mysql is complainting.
					//$retval = mysql_query( $sql, $link ) or die("error in Query: $sql ". mysql_error());
					
					//echo "<script>alert('did the retrieval die or not = $retval')</script>";
					
					//$row = mysql_fetch_array($retval);
					
					// put the rows from the query into a variable
						
					$NumOfrows = mysql_num_rows($retval);
					
					
					// if rows is > 0 ... so the goal/indicator exist
						
					if($NumOfrows > 0 )
					{
		  				//$msg = "Ops. the goal seems like it has been entered already\n";
						//echo "<script>alert('$msg')</script>";
						
						//only if the retrieval is produces a record then the return 
						//value is True, the goal had already being entered.
						$giExist = TRUE;
						
						//echo "<script>alert('goal and ind have already being entered: rows = $NumOfrows ')</script>";	
		  				
					}
					else // if no row is found all is good so no need for message.
					{
						//echo "<script>alert('goal and first ind doesnt exist')</script>";
						//echo "<script>alert('rows = $NumOfrows > 0')</script>";					
						//don't do anyting
		  				;
															
					}
						
					// Close de conection
						
					mysql_close($link);
							
				}
					
			
			
			//variables to be returned
			
			return $giExist;
			
			
		}
		
		/**
		 * btnsave_Click function
		 * 
		 * *********************************************************************************
		 * *****************this is the main function of this form**************************
		 * *********************************************************************************
		 * will take the goal and first indicator and will check if such goal exist, if it 
		 * doesnt will save the goal, get the goal id and then will add the indicators tie 
		 * them up with the goal indicator into the respective database tables.
		 *  
		 */	
		function btnsave_Click()
		{
			
		
			//echo "<script>alert('tbnsave_Click is being executed')</script>";
			//Set variables with values from form, class, period, goal and indicators 
			
			/*
			 * " " (ASCII 32 (0x20)), an ordinary space.
				"\t" (ASCII 9 (0x09)), a tab.
				"\n" (ASCII 10 (0x0A)), a new line (line feed).
				"\r" (ASCII 13 (0x0D)), a carriage return.
				"\0" (ASCII 0 (0x00)), the NUL-byte.
				"\x0B" (ASCII 11 (0x0B)), a vertical tab.
			 */ 
			
			$charlist = "\t\n\r\0\x0B"; //charlist of characters to remove from goal and indicator strings	
			$indArray = array(); //array for indicators
			$GoalIndicatorExistYet = FALSE;
			$goaladdedOK = FALSE;
			$msg = 1;
			/************************************************************
			 * get the data from the form and sanitize it if needed *****
			 ************************************************************
			 * 
			 * */
			 
			$cclass = $_POST["ddboxClassSubject"]; // get the class and subject from dropdown and put it into a variable
			
			
			$period = $_POST["rdPeriod"]; // get the period and put it into a variable
			
			
			$goal = mysql_real_escape_string($_POST["tbgoal"]); //get the goal and sanitize the input then put into a variable
			$goal = trim ($goal, $charlist); // remove hasty character from beginning and end of the string
			
			//get all the indicators and put into an array
			
			foreach ($_POST as $key => $value ) // iterate through all the elements in POST array (form)
			{
				//if the name of the post element has the word tbIndicator and its value is not empty.
				//$teststrpos = strpos($key,"tbIndicator");
				//$testempty = !empty($value); 
				
				if (strpos($key,'tbIndicator') === 0 && !empty($value) > 0) //if strpos found at the biginning === 0 and if not empty > 0
				{
					$value = mysql_real_escape_string($value); //sanitize the contents of its respective value
					$value = trim ($value, $charlist); // remove hasty characters from the beginning and end of the value
					array_push($indArray, $value); //put the value onto the array 
					//echo "<script>alert('ind just pushed into array = $value')</script>";
					//echo "<script>alert(' values pushed into array: key = $key and value = $value , teststrpos = $teststrpos , testempty = $testempty ')</script>>";
				}
			}
			
			//is there at least one indicator, period selected, class selected and is there text for the goal?
			
			if (strlen($indArray[0]) > 0 && $cclass > 0 && $period > 0  && strlen($goal) > 0)
			{
				
				//'check to see if the same period, goal text, first indicator text and class have already
		        //being entered
					
				$GoalIndicatorExistYet = GoalIndicatorExist($period,$goal,$indArray[0],$cclass);
				//echo "<script>alert('goalIndicatorExistYet = $GoalIndicatorExistYet')</script>";
				
				//only if the retrieval produces a record then the return 
				//value is True, the goal had already being entered.
				
				if($GoalIndicatorExistYet == 1) //trows 1 if goal and indicator being entered already exist
				{
						
					$msg = "Ops. the goal seems like it has been entered already";
					echo "<script>alert('$msg')</script>";
						
				}
				else //if the goal being entered does not exist then ...
				{				
					$goaladdedOK = AddGoal($goal,$period); // try to add the goal
					
					// if goal added ok (not 0) then
					//echo "<script>alert('goaladdedOK = $goaladdedOK')</script>";
					
					if($goaladdedOK != 0)
					{
						
						//lets add the indicators
						
						foreach ($indArray as $key => $value) //iterate through the indicators array
						{
							$indaddedOK = addIndicator($value, $goaladdedOK, $cclass); //add an ind to the table.
							
							if ($indaddedOK = 0) // if something goes wrong report it a message.
							{
								echo "<script>alert('something went wrong adding the an indicator')</script>"; // something when wrong when adding the indicator
								$msg = "adding an indicator failed";
								break;	// break the loop
							}						
						}		 
						
					}
				}
			} 
			else 
			{
				//return a message confirming that there's something no entered properly
				
				$msg = "check the that there's a class, period, a goal and at least an indicator entered";	
			}			
			
			return $msg;    
		}
		
			
?>